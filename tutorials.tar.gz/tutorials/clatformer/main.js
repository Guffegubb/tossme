
var mainState = {
    preload: function() {
        //game.load.image('player', 'assets/alienPink_walk1.png');
        game.load.image('wall', 'assets/dirtMid.png');
        game.load.image('coin', 'assets/star.png');
        game.load.image('enemy', 'assets/sandMid.png');
        game.load.spritesheet('player', 'assets/spritesheet_players.png', 128, 256, 2);
        // ev loadAtlasXML och flytta in XML-filen
        
        //game.load.image();
        //game.load.image();
    },
    
    create: function() {
        
        game.stage.backgroundColor = '#3598db';
        game.physics.startSystem(Phaser.Physics.ARCADE);
        game.world.enableBody = true;
        game.world.setBounds(0, 0, 4000, 4000);
        
        this.cursor = game.input.keyboard.createCursorKeys();
        
        this.player = game.add.sprite(400, 400, 'player');
        this.player.body.gravity.y = 600;
        // This is a try on animation
        //var walk = player.animations.add('walk');
        //player.animations.play('walk', 30, true);
        
        // End of try
        
        this.walls = game.add.group();
        this.coins = game.add.group();
        this.enemies = game.add.group();
    
        // Design the level. x = wall, o = coin, ! = lava.
        var level = [
            'xxxxxxxxxxxxxxxxxxxxxx',
            '!         !          x',
            '!                 o  x',
            '!         o          x',
            '!                    x',
            '!     o   !    x     x',
            'xxxxxxxxxxxxxxxx!!!!!x',
        ];
        
        for (var i = 0; i < level.length; i++) {
            for (var j= 0; j < level[i].length; j++)  {
                
                
                if (level[i][j] == 'x') {
                    var wall = game.add.sprite(30 + 160*j, 30 + 160*i, 'wall');
                    this.walls.add(wall);
                    wall.body.immovable = true;
                }
                
                else if (level[i][j] == 'o') {
                    var coin = game.add.sprite(30 + 160*j, 30 + 160*i, 'coin');
                    this.coins.add(coin);
                }
                
                else if (level[i][j] == '!') {
                    var enemy = game.add.sprite(30 + 160*j, 30 + 160*i, 'enemy');
                    this.enemies.add(enemy);
                }
                
                
            }
        }
        
       game.camera.follow(this.player);
       //this.camera.follow(player, Phaser.Camera.FOLLOW_LOCKON); 
        
    },
    
    update: function() {
        
        

            
        game.physics.arcade.collide(this.player, this.walls);
        
        game.physics.arcade.overlap(this.player, this.coins, this.takeCoin, null, this);
        
        game.physics.arcade.overlap(this.player, this.enemies, this.restart, null, this);
        
        if (this.cursor.left.isDown) 
            this.animateWalk();
            //this.player.body.velocity.x = -350;
        else if (this.cursor.right.isDown) 
            this.player.body.velocity.x = 350;
        else 
            this.player.body.velocity.x = 0;
            
        if (this.cursor.up.isDown && this.player.body.touching.down)
            this.player.body.velocity.y = -650;
            
        
        
    },
    
    takeCoin: function(player, coin) {
        coin.kill();
    },
    
    restart: function() {
        game.state.start('main');
    }, 
    
    animateWalk: function() {
        //var playerframes = new FrameData();
          //  playerframes.addFrame('player');
            //playerframes.addFrame('player2');
        this.player.body.velocity.x = -350;
        //var walk = player.animations.add(this, player,'walk', playerframes,[0,1], 60,true);
        //player.animations.play('walk');
    }
};


var game = new Phaser.Game(1920, 1080);
game.state.add('main', mainState);
game.state.start('main');

