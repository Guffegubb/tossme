// video 9 for enemybird

EnemyBird = function(index, game,x,y) {
  
  // "this variable will now be global to our classes"
  this.bird = game.add.sprite(x,y,'bird');
  this.bird.anchor.setTo(0.5,0.5);
  //give every enemy bird a name (which will be its index)
  this.bird.name = index.toString();
  game.physics.enable(this.bird, Phaser.Physics.ARCADE);
  this.bird.body.immovable = true;
  this.bird.body.collideWorldBounds = true;
  
   //vid 10
  this.bird.body.allowGravity = false;
  
  //vid 9
  this.birdTween = game.add.tween(this.bird).to({
    y: this.bird.y + 100
  }, 2000, 'Linear', true,0,100,true);
  
 
  
}

//vid 10
var enemy1;


Game.Level1 = function(game){};

var map;
var layer;

var player;
var controls = {};
var playerSpeed = 150;
var jumpTimer = 0;

var button;
var drag;

//vid 11
var shootTime = 0;
var nuts;

//vid 14
var respawn;

// vid 15
var playerXP = 0;
var gameXPsteps = 15;
var playerLevel = 0;

Game.Level1.prototype = {
    
    // in tutorial 9 he adds game as a parameter to create:function, something with being able to use both game and this. "sometiumes it doesnt work"..
    create:function(game){ 
      this.stage.backgroundColor = '#3A5963'; 
      
      this.physics.arcade.gravity.y = 1000;
      
      respawn = game.add.group();
      
      //The old one is for csv
      //map = this.add.tilemap('map', 64, 64);
      map = this.add.tilemap('map');
      map.addTilesetImage('tileset', 'tileset');
      
      
      layer = map.createLayer('Tile Layer 1');
      layer.resizeWorld();
    
      
      // from tutorial 3, creating collisions with the map below
      map.setCollisionBetween(0,4); //this will be fucked up apparently according to video
      
      
      
      
      // OBS, setTileIndexCallback from tut 6 and 7 will be bugged after vid 14, change to this:
      map.setTileIndexCallback(7, this.getCoin, this);
      map.setTileIndexCallback(6, this.spawn, this);
      
      
      // tut 6
      //map.setTileIndexCallback(5, this.resetPlayer, this);
      // tutorial #7
      //map.setTileIndexCallback(6, this.getCoin, this);
      //
      
      
      // vid 16
      map.setTileIndexCallback(9, this.speedPowerup, this);
      
      //Vid 14 for json
      map.createFromObjects('Object Layer 1', 8, '', 0, true, false, respawn);
      
      
      player = this.add.sprite(0, 0, 'player');
      player.anchor.setTo(0.5,0.5);
      player.animations.add('idle',[0,1],1,true);
      player.animations.add('jump',[2],1,true);
      player.animations.add('run', [3,4,5,6,7,8],7,true);
      this.physics.arcade.enable(player);
      this.camera.follow(player);
      player.body.collideWorldBounds = true;
      // ugly code that solves spawn problem yaaaay
      this.spawn();
      
      controls = {
        right: this.input.keyboard.addKey(Phaser.Keyboard.D),
        left: this.input.keyboard.addKey(Phaser.Keyboard.A),
        up: this.input.keyboard.addKey(Phaser.Keyboard.W),
        //vid 11 - he uses up arrow key for shoot, I put space instead
        shoot: this.input.keyboard.addKey(Phaser.Keyboard.SPACEBAR),
        
      };
      
      button = this.add.button(this.world.centerX - 95, this.world.centerY + 200, 'buttons', function(){
        console.log('pressed');
      }, this, 2,1,0);
      
      button.fixedToCamera = true;
      
      
      //tutorial 8, make an object draggable by the mouse. 
      drag = this.add.sprite(player.x, player.y, 'drag');
      drag.anchor.setTo(0.5,0.5);
      drag.inputEnabled = true;
      drag.input.enableDrag(true);
      
          
    // vid 9 / 10
    enemy1 = new EnemyBird(0, game, player.x+400, player.y-200);
    
    
    // vid 11
    // not sure what the 5 in createMultiple does. At the moment got infinite number of shots, maybe just need to remove one element from the nuts group each shot.
    nuts = game.add.group();
    nuts.enableBody = true;
    nuts.physicsBodyType = Phaser.Physics.ARCADE;
    nuts.createMultiple(5,'nut');
    nuts.setAll('anchor.x', 0.5);
    nuts.setAll('anchor.y', 0.5);
    
    nuts.setAll('scale.x', 0.5);
    nuts.setAll('scale.y', 0.5);
    
    nuts.setAll('outOfBoundsKill', true);
    nuts.setAll('checkWorldBounds', true);
      
    },
    
    update:function() {
    // just uncommented after adding map
    this.physics.arcade.collide(player, layer);
    
    //vid 12, line below is fix for bug introduced with shooting in vid 11
    this.physics.arcade.collide(player, enemy1.bird, this.resetPlayer);

    player.body.velocity.x = 0;
    
    // vid 15
    playerLevel = Math.log(playerXP, gameXPsteps);
    console.log('Level: ' + Math.floor(playerLevel));
    // endof vid 15
    
    if(controls.right.isDown){
      player.animations.play('run');
      player.scale.setTo(1,1);
      player.body.velocity.x += playerSpeed;
    }
     
     
    if(controls.left.isDown){
      player.animations.play('run');
      player.scale.setTo(-1,1);
      player.body.velocity.x -= playerSpeed;
    }
    
    if(controls.up.isDown && (player.body.onFloor() || 
    player.body.touching.down) && this.time.now > jumpTimer) {
      player.body.velocity.y =-800;
      jumpTimer = this.time.now + 750;
      player.animations.play('jump');
    }
    
    if(player.body.velocity.x == 0 && player.body.velocity.y == 0){
      player.animations.play('idle');
    }
    
    
    
    //vid 10
    // this creates a bug when shooting is introduced, can get killed when touching where the bird used to be before dying
    //commented this and added the fix further up. commented as vid 12, top of update function. 
    //if(checkOverlap(player,enemy1.bird)){
    //  
    //  this.resetPlayer();
    //}
    
    
    //vid 11
    if(controls.shoot.isDown) {
      this.shootNut();
    }
    
    //vid 11
    if(checkOverlap(nuts,enemy1.bird)) {
      enemy1.bird.kill();
    }
    
    },
    
    
    
    //from tutorial 6 (should add start position as variables etc in own game)
    //
     resetPlayer:function() {
        player.reset(100, 560)      
     },
    
    //vid 14
    spawn: function() {
      
      respawn.forEach(function(spawnPoint) {
        
        player.reset(spawnPoint.x, spawnPoint.y);
        
      }, this)
      
    },
    
    
    // tutorial 7 - but think from the lessmilk tutorial had a better way of removing coins than this one, check 2d platformer (clatformer) code
     getCoin:function() {
      map.putTile(-1, layer.getTileX(player.x),layer.getTileY(player.y));
      
      // vid 15
      playerXP += 15;
    },
    
    // vid 16
    speedPowerup:function() {
      map.putTile(-1, layer.getTileX(player.x),layer.getTileY(player.y));
      playerSpeed += 50;
      
      // create a timer for 2 seconds, after which speed will decrease to return to normal
      this.time.events.add(Phaser.Timer.SECOND * 2, function() {
        playerSpeed -= 50;
      })
    },
    
    //vid 11
    shootNut:function() {
      if(this.time.now > shootTime) {
        nut = nuts.getFirstExists(false);
        if(nut) {
          nut.reset(player.x, player.y);
          nut.body.velocity.y = -700;
          shootTime = this.time.now + 600;
          
          // vid 15. For testing purposes, should not get xp just for shooting normally.
          playerXP += 15;
          
        }
      }
    }


  
   
}

  // vid 10
 function checkOverlap(spriteA, spriteB) {
      
      var boundsA = spriteA.getBounds();
      var boundsB = spriteB.getBounds();
      return Phaser.Rectangle.intersects(boundsA, boundsB);
    }
    